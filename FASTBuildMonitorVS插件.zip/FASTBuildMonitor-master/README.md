# FASTBuild Monitor
![msfastbuild example image](http://dualsoftinc.com/wp-content/uploads/2016/09/FASTBuildMonitorScreenshot.png "msfastbuild example")

https://www.youtube.com/watch?v=saxFpmNq_Vw

A graphical Visualizer for FASTBuild (Supports VS 2012, 2013, 2015, 2017). Now officially supported by FASTBuild starting v0.92 



##Instructions :

1) Download the Release zip file.

2) Install the VSIX package FASTBuildMonitorVSIX.vsix

4) Restart VisualStudio and Click on Tools->FASTBuildMonitor

5) Download FASTBuild 0.92 or higher (http://fastbuild.org/docs/download.html).

6) Launch FBuild.exe with the -monitor argument

7) The FASTBuildMonitor VS extension should show the live build activity (or the previous build results).
